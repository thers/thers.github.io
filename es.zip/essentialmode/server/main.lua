﻿-- Server
Users = {}
commands = {}

require "resources/essentialmode/lib/MySQL"

AddEventHandler('playerConnecting', function(name, setCallback)
	local identifiers = GetPlayerIdentifiers(source)
		for i = 1, #identifiers do
			local identifier = identifiers[i]
			local banned = checkBan(identifier)
			print("Essential | Checking user ban: (" .. name .. ") " .. identifier)

			if(banned)then
				if(tonumber(banned.banned) == 1)then
			  		setCallback(banned.banreason)
					CancelEvent()
				end
			return
	    end
	end
end)

AddEventHandler('playerDropped', function()
	Users[source] = nil
end)

local justJoined = {}

RegisterServerEvent('es:firstJoinProper')
AddEventHandler('es:firstJoinProper', function()
	local identifiers = GetPlayerIdentifiers(source)
	for i = 1, #identifiers do
		if(Users[source] == nil)then
			print("Essential | Loading user: " .. GetPlayerName(source))

			local identifier = identifiers[i]
			registerUser(identifier, source)

			TriggerEvent('es:initialized', source)
			justJoined[source] = true
		end
	end
end)

RegisterServerEvent('playerSpawn')
AddEventHandler('playerSpawn', function()
	if(justJoined[source])then
		TriggerEvent("es:firstSpawn", source)
		justJoined[source] = nil
	end
end)

AddEventHandler("onResourceStart", function(name)
	if(name ~= "essentialmode")then
		return
	end

	print("Resource restarted, loading users...")

	for value = 0, 1000 do
		local identifiers = GetPlayerIdentifiers(value)
		for i = 1, #identifiers do
			if(Users[value] == nil)then
				print("Essential | Loading user: " .. GetPlayerName(value))

				local identifier = identifiers[i]
				registerUser(identifier, value)
			end
	    end
	end
	print("Done")

	TriggerEvent("es:reloaded")
end)

AddEventHandler('chatMessage', function(source, n, message)
	if(startswith(message, "/"))then
		local command_args = stringsplit(message, " ")

		command_args[1] = string.gsub(command_args[1], "/", "")

		local command = commands[command_args[1]]

		if(command)then
			CancelEvent()
			if(command.perm > 0)then
				if(tonumber(Users[source]['permission_level']) >= command.perm)then
					command.cmd(source, command_args, Users[source])
					TriggerEvent("es:adminCommandRan", source, command_args)
				else
					command.callbackfailed(source, command_args, Users[source])
				end
			else
				command.cmd(source, command_args, Users[source])
			end
		end
	end
end)

AddEventHandler('es:addCommand', function(command, callback)
	commands[command] = {}
	commands[command].perm = 0
	commands[command].cmd = callback
end)

AddEventHandler('es:addAdminCommand', function(command, perm, callback, callbackfailed)
	commands[command] = {}
	commands[command].perm = perm
	commands[command].cmd = callback
	commands[command].callbackfailed = callbackfailed
end)

RegisterServerEvent('es:updatePositions')
AddEventHandler('es:updatePositions', function(x, y, z)
		if(Users[source])then
			Users[source].coords = {['x'] = x, ['y'] = y, ['z'] = z}
		end
end)

-- Info command
commands['info'] = {}
commands['info'].perm = 0
commands['info'].cmd = function(source, args, user)
	TriggerClientEvent('chatMessage', source, 'SYSTEM', {255, 0, 0}, "^2[^3EssentialMode^2]^0 Version: ^20.2.2")
	TriggerClientEvent('chatMessage', source, 'SYSTEM', {255, 0, 0}, "^2[^3EssentialMode^2]^0 Commands loaded: ^2" .. (returnIndexesInTable(commands) - 1))
end
